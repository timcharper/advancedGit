require File.dirname(__FILE__) + '/../spec_helper.rb'

describe Command::Reverse do
  before(:each) do
    @doc = Document.new('groovy')
  end

  describe "#execute" do
    it "causes the document to be reversed" do
      command = Command::Reverse.new(@doc)
      command.execute
      @doc.content.should == "yvoorg"
    end
  end

  describe "#unexecute" do
    it "restores the document to the previous state" do
      command = Command::Reverse.new(@doc)
      command.execute
      @doc.content.should == "yvoorg"
      command.unexecute
      @doc.content.should == "groovy"
    end
  end
end
