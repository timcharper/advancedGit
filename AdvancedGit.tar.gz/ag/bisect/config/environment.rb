PROJECT_ROOT = File.expand_path('..', File.dirname(__FILE__))

require PROJECT_ROOT + '/lib/document.rb'
require PROJECT_ROOT + '/lib/command.rb'
