require File.dirname(__FILE__) + '/../spec_helper.rb'

describe Command::Upcase do
  before(:each) do
    @doc = Document.new('Groovy')
  end

  describe "#execute" do
    it "causes the document to be upcased" do
      command = Command::Upcase.new(@doc)
      command.execute
      @doc.content.should == "GROOVY"
    end
  end

  describe "#unexecute" do
    it "causes the change to be reversed" do
      command = Command::Upcase.new(@doc)
      command.execute
      @doc.content.should == "GROOVY"
      command.unexecute
      @doc.content.should == "Groovy"
    end
  end
end
