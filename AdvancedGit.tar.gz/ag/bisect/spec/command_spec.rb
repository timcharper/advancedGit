require File.dirname(__FILE__) + '/spec_helper.rb'
describe Command do
  before(:each) do
    @doc = Document.new('This is the greatest document ever.')
  end
  
  describe "::new" do
    it "accepts target document" do
      command = Command.new(@doc)
      command.target.should == @doc
    end

    it "raises if you pass an invalid parameter" do
      running {
        Command.new("boo")
      }.should raise_error(ArgumentError, /invalid/)
    end
  end
end
