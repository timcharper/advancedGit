require File.dirname(__FILE__) + '/spec_helper.rb'
describe Document do
  describe "::new" do
    it "accepts a string for it's content" do
      doc = Document.new('snorkle')
      doc.content.should == 'snorkle'
    end
  end
  
  describe "#content" do
    it "returns the document's content" do
      doc = Document.new('snorkle')
      doc.content.should == 'snorkle'
    end
  end
  
  describe "#content=" do
    it "sets the documents content" do
      doc = Document.new
      doc.content = "content"
      doc.content.should == "content"
    end
  end
end

