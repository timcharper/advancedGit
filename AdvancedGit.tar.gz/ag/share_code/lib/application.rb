class Application

  def initialize
    puts "It doesn't do anything awesome"
  end
end
