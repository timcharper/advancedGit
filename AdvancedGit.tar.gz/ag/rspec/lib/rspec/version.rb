module RSpec # :nodoc:
  module Version # :nodoc:
    STRING = '2.0.0.rc'
  end
end
