# Be sure to restart your server when you modify this file.

# Your secret key for verifying cookie session data integrity.
# If you change this key, all old sessions will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.session = {
  :key         => '_submodules_session',
  :secret      => '410193b77c812e40268f14958ca1d9a82b2bc18305eb84b178c781ee0a5ef5b7a8bdf3cd14d6524f97615e0422aaabaf970790907ff77a1d011575fb33487c87'
}

# Use the database for sessions instead of the cookie-based default,
# which shouldn't be used to store highly confidential information
# (create the session table with "rake db:sessions:create")
# ActionController::Base.session_store = :active_record_store
