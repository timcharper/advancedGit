# the reverse command will basically solve all of your problems by reversing everything wrong you do
class Command::Reverse < Command
  def execute
    super
    target.content = target.content.reverse
  end
end
