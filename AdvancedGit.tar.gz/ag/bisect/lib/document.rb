class Document
  attr_accessor :content
  
  def initialize(content = "")
    @content = content
  end
  
  def initialize_from_copy(other)
    @content = other.content.dup
    self
  end
  
  def to_s
    @content
  end
end
