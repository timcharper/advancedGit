class Command::Upcase < Command
  def execute
    super
    target.content = target.content.upcase
  end
end
