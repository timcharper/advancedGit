require 'rubygems'
require 'spec'

require File.dirname(__FILE__) + '/../config/environment.rb'
