# This is a Command class
class Command
  autoload :Reverse, PROJECT_ROOT + '/lib/command/reverse.rb'
  autoload :Upcase, PROJECT_ROOT + '/lib/command/upcase.rb'
  attr_reader :target, :previous_content
  def initialize(target)
    raise(ArgumentError, "invalid target! Expected a Document but received a '#{target.class}' instead") unless target.is_a?(Document)
    @target = target
  end
  
  # execute the command
  def execute
    previous_content = target.content
  end
  
  # undo the command (restore target to previous state)
  def unexecute
    target.content = previous_content
  end

end
